=============================================================
unbound SMF Installation & Remove   (C) 2007,2020 Yuri Voinov
=============================================================

***  WARNING!  The  default  package  set  to  run  unbound,
installed in / usr / local!

This set of scripts for installation and removal SMF service
for unbound daemon for Sun Solaris 10 and above.

All  the  necessary  prerequisites needed to run the service
unbound,  according  to  the manual configuration (excluding
the  actual  configuration  of unbound) performed during the
installation  of  service,  removal  service SMF removes all
scripts and performs deregister service unbound and stop.

To activate the unbound SMF follow these steps:
------------------------------------------------------------

1.  Set up the unbound and all necessary libraries, if it is
not already.

2. Configure the unbound editing unbound.conf.

***  WARNING!  The  default  package  set  to  run  unbound,
installed in / usr / local!

4. Run the script unbound_smf_inst.sh, that performs all the
necessary  prerequisites  and  post action� and will install
unbound SMF service.

5.  Run  the  command  svcadm enable unbound to activate and
start the service unbound.

To  deactivate  and remove unbound SMF service, follow these
steps:
------------------------------------------------------------

1. Start the script unbound_smf_rmv.sh. The script stops all
running  unbound  processes,  de-registers  SMF service, and
completely   removes   SMF  and  rolls  back  the  operation
performed earlier in the activation of the service.

*** Note: Removal of unbound SMF service does not remove the
installed software unbound.

Archive contains:

init.unbound        - Managing method unbound SMF
unbound.xml         - Service manifest unbound SMF
readme_ru.txt         - ���� ���� (Russian)
readme_en.txt         - This file (English)
unbound_smf_inst.sh    - SMF Installation script
unbound_smf_rmv.sh     - SMF Removal script

=============================================================
unbound SMF Installation & Remove   (C) 2007,2020 Yuri Voinov
=============================================================